/*
 * pid.c
 *
 *  Created on: 2025��5��29��
 *      Author: lenovo
 */
#include "zf_common_headfile.h"
#define FEEDFORWARD_GAIN    -0.5f
#define DT                  0.01f
#define INERTIA_TIME        0.02f
#define FF_WINDOW_SIZE 5  // ǰ�����ô��ڣ�������������
#define ACCEL_INTEGRAL_DECAY 0.9f
#define Ts 0.01f
#define Tf 0.005f
float    SPEEDMAX = 1500.0;

AnglePid an_pid;
AttitudePid att_pid;
HybridController ctrl;

float current_ff;
int32 Velocity_in(int32 Target,int16 Lspeed,int16 Rspeed)//�ٶȻ�
{
    static float Err_v[3], d_term_last = 0,delta_pid,filtered_Vel_Pre,Vel_PWM_OUT;
    static int32 Last_Target = 0,ff_index = 0;
    static float accel_integral,Target_accel,effective_ff,ff_buffer[FF_WINDOW_SIZE] = {0};

    current_ff = FEEDFORWARD_GAIN * (Target + INERTIA_TIME * Target_accel);
    Err_v[0]=((Lspeed - Rspeed) / 2.0) - Target;//���
    // 1. ������ٶ�
    float raw_accel = (Target - Last_Target) / DT;
    // 2. ���ٶȻ��֣���˥����
    accel_integral = ACCEL_INTEGRAL_DECAY * accel_integral
                   + (1-ACCEL_INTEGRAL_DECAY) * raw_accel;
    // 3. ���ڻ�ǰ������
    ff_buffer[ff_index] = FEEDFORWARD_GAIN
                        *(raw_accel * DT
                        + INERTIA_TIME * accel_integral);
    ff_index = (ff_index + 1) % FF_WINDOW_SIZE;
    // 4. ������Чǰ��
    for(int i=0; i<FF_WINDOW_SIZE; i++)
        {
            effective_ff += ff_buffer[i] * (FF_WINDOW_SIZE - i);
        }
    effective_ff /= (FF_WINDOW_SIZE*(FF_WINDOW_SIZE+1)/2); // ����Ȩ�ع�һ��

    PWM_Limitf(&effective_ff,1500.0);

    float alpha = Ts /(Ts+Tf);
    float d_term = (1-alpha) * att_pid.Velocity_kd * ( Err_v[0] - Err_v[1])+alpha * d_term_last;
    d_term_last = d_term;
    delta_pid += att_pid.Velocity_kp * ( Err_v[0] - Err_v[1] )
              + att_pid.Velocity_ki * Err_v[0]
              + d_term;

    float filtered_Vel = 0.8 * filtered_Vel_Pre + (1-0.8) * delta_pid;
    Vel_PWM_OUT = filtered_Vel  + effective_ff  ;

    PWM_Limitf(&Vel_PWM_OUT ,SPEEDMAX);

    Last_Target = Target;
    Err_v[2] = Err_v[1];
    Err_v[1] = Err_v[0];
    filtered_Vel_Pre = filtered_Vel;
    return Vel_PWM_OUT ;
}
#define BRAKE_THRESHOLD  350.0f    // ����ɲ�����ٶȲ���ֵ
#define MAX_BRAKE_TORQUE  -1000.0f  // ����ƶ�Ť�أ���ֵ��ʾ�ƶ���
#define BOOST_TORQUE     600.0f    // ���ٽ׶����Ť��
#define CROSSOVER_ERROR  2.0f     // �л���PID���Ƶ������ֵ
int16 SINGLE_BRITGH_FLAG = 0,_SINGLE_BRITGH_FLAG = 0,hybrid_control_flag = 0;
float hybrid_control(HybridController* ctrl,int32 Target,int16 Lspeed,int16 Rspeed)
{
    int16 current = ((Lspeed - Rspeed) / 2.0);//���
    int16 error = Target - current;
    float abs_error = fabsf(error);
    float output = 0;
    // �׶ξ����߼�
    if(abs_error >= BRAKE_THRESHOLD)
    {
        if(error >= BRAKE_THRESHOLD)
        {
            ctrl->phase = PHASE_BRAKING;
            //ctrl->brake_start_time = get_system_time();
        }
        else if(error <= -BRAKE_THRESHOLD)
        {
            ctrl->phase = PHASE_NORMAL;
            //ctrl->boost_start_time = get_system_time();
        }
    }
  /*  else if(abs_error < CROSSOVER_ERROR)
    {
        ctrl->phase = PHASE_NORMAL;
    }*/
    switch(ctrl->phase)
    {
        case PHASE_BRAKING:
        {
            if(hybrid_control_flag)
            {
                output = MAX_BRAKE_TORQUE;
                if(current > -400.0f && Target < current)
                {
                    SINGLE_BRITGH_FLAG = 1;
                    ctrl->phase = PHASE_BOOSTING;
                }
            }
            //else  ctrl->phase = PHASE_BOOSTING;
            break;
        }
        case PHASE_BOOSTING: {
                output = BOOST_TORQUE;
             if(fabsf(Target - current) < (BRAKE_THRESHOLD/2)) {
                ctrl->phase = PHASE_NORMAL;
                 }
             break;
        }
        case PHASE_NORMAL: {
            output = Velocity_in(att_pid.Targetspeed,Lspeed,Rspeed);
            if( SINGLE_BRITGH_FLAG == 1 ) _SINGLE_BRITGH_FLAG = 1;
            break;
        }
    }
    ctrl->last_output = output;
    return output;
}
#define up_limit 3
float up_right(float speed,float Expect_Med,float angle)
{
    static float err,out_duty,last_err;

    err=angle-Expect_Med;
    out_duty=an_pid.angle_kp*(err+speed)+an_pid.angle_kd*(err-last_err);
    last_err=err;

    if(out_duty>=up_limit)
        out_duty=up_limit;
    else if(out_duty<=-up_limit)
        out_duty=-up_limit;
    return out_duty;
}
//���ٶȻ�
#define integral_xian 35.0
#define an_limit 35.0
float Angular_Rate_Loop(float expect_up_speed, float gyro)
{
    static float out_duty,err,integral;
    err=expect_up_speed-gyro;
    integral+=an_pid.angle_Velocity_ki*err;
    if(integral>=integral_xian)
        integral=integral_xian;
    else if(integral<=-integral_xian)
        integral=-integral_xian;
    out_duty= an_pid.angle_Velocity_kp*err+integral;

    if(out_duty>=an_limit)
        out_duty=an_limit;
    else if(out_duty<=-an_limit)
        out_duty=-an_limit;

    return out_duty;
}
int32 Turn(int32 speed,float gyro_z)
{
    int32 PWM_OUT,last_speed = 0;

    PWM_OUT = att_pid.Turn_kp1 * speed
            + att_pid.Turn_kp2 * speed * abs(speed)
            + att_pid.Turn_kd  * (speed - last_speed)
            + att_pid.Gyro_GKD * gyro_z
            + att_pid.Gyro_GKD_1 * Z_Yaw ;
    last_speed = speed;
    return (int32)PWM_OUT;
}



