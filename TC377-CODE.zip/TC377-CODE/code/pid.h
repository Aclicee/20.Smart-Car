/*
 * pid.h
 *
 *  Created on: 2025��5��29��
 *      Author: lenovo
 */

#ifndef CODE_PID_H_
#define CODE_PID_H_

typedef struct
{
    float Velocity_kp;
    float Velocity_ki;
    float Velocity_kd;
    int32 Velocity_out;

    float Turn_kp1;
    float Turn_kp2;
    float Turn_kd;
    float Gyro_GKD;
    float Gyro_GKD_1;
    int32 Turn_out;

    float Med_Angle;
    int32 Targetspeed;
}AttitudePid;
typedef struct
{
    float angle_kp;
    float angle_ki;
    float angle_kd;
    float angle_Velocity_kp;
    float angle_Velocity_ki;
    float angle_Velocity_kd;
}AnglePid;
typedef enum {
    PHASE_NORMAL,    // ����PID����
    PHASE_BRAKING,   // ȫ���ƶ��׶�
    PHASE_BOOSTING   // ���ټ��ٽ׶�
}ControlPhase;

typedef struct
{
    ControlPhase phase;      // ��ǰ���ƽ׶�
    float brake_start_time;  // �ƶ���ʼʱ���
    float boost_start_time;  // ���ٿ�ʼʱ���
    float last_output;       // �ϴ����ֵ
}HybridController;

extern HybridController ctrl;
extern AnglePid an_pid;
extern AttitudePid att_pid;

extern float SPEEDMAX;
extern int16 hybrid_control_flag;
extern int32 Target_FF;
extern int Single_sided_bridge_flag;
extern float current_ff;
extern float Target_accel;
extern int8 error;

int32 Velocity_in(int32 Target,int16 Lspeed,int16 Rspeed);

int32 Vertical(float Mid,float Pitch,float gyro_y);

int32 Turn(int speed,float gyro_z);


#endif /* CODE_PID_H_ */
