/*
 * duoji.h
 *
 *  Created on: 2025��1��3��
 *      Author: lenovo
 *//*
 * duoji.h
 *
 *  Created on: 2025��1��3��
 *      Author: lenovo
 */

#ifndef CODE_SERVO_H_
#define CODE_SERVO_H_

#define L1 6
#define L2 9
#define L3 9
#define L4 6
#define L5 3.8

#define SELECTED_OBJECT 2

#if (SELECTED_OBJECT == 1)
    #define SERVO_1                 (ATOM0_CH1_P21_3)     //  ��ǰ
    #define SERVO_2                 (ATOM0_CH0_P21_2)     //  ���
    #define SERVO_3                 (ATOM0_CH3_P21_5)     //  ��ǰ
    #define SERVO_4                 (ATOM0_CH2_P21_4)     //  �Һ�
    #define SERVO_FREQ              (300)                   //���Ƶ��
    #define SERVO1_MID              (4280)                    //���1��ֵ     ��ǰ
    #define SERVO2_MID              (4320)                    //���2��ֵ     ���
    #define SERVO3_MID              (4350)                    //���3��ֵ     ��ǰ
    #define SERVO4_MID              (4300)                    //���4��ֵ     �Һ�
#elif (SELECTED_OBJECT == 2)
    #define SERVO_1                 (ATOM0_CH1_P21_3)     //  ��ǰ
    #define SERVO_2                 (ATOM0_CH0_P21_2)     //  ���
    #define SERVO_3                 (ATOM0_CH2_P21_4)     //  ��ǰ
    #define SERVO_4                 (ATOM0_CH3_P21_5)     //  �Һ�
    #define SERVO_FREQ              (300)                   //���Ƶ��
    #define SERVO1_MID              (4400)                    //���1��ֵ     ��ǰ
    #define SERVO2_MID              (4900)                    //���2��ֵ     ���
    #define SERVO3_MID              (4800)                    //���3��ֵ     ��q
    #define SERVO4_MID              (4600)                    //���4��ֵ ��ǰ
#endif
typedef struct
{
    float XLeft;
    float YLeft;
    float Y_demand;
    float XRight;
    float YRight;
    float alphaLeft;
    float betaLeft;
    float alphaRight;
    float betaRight;
    float kp;
    float RB_Roll;
    float TargetLenth;
}Coor;

extern Coor wheel;

void AngleCal(float XL,float XR ,float YL, float YR);
void Servo_Init(void);
void Single_sided_bridge();
void Mid_Set();
float BendTurnControl();

extern int servoLeftRear;
extern int servoLeftFront;
extern int servoRightRear;
extern int servoRightFront;

#endif /* CODE_SERVO_H_ */


