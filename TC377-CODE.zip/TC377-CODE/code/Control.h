/*
 * Control.h
 *
 *  Created on: 2025��1��14��
 *      Author: lenovo
 */

#ifndef CODE_CONTROL_H_
#define CODE_CONTROL_H_
/*
typedef struct
{
    float Velocity_kp;
    float Velocity_ki;
    float Velocity_kd;
    int32 Velocity_out;

    float Turn_kp1;
    float Turn_kp2;
    float Turn_kd;
    float Gyro_GKD;
    float Gyro_GKD_1;
    int32 Turn_out;

    float Med_Angle;
    int32 Targetspeed;
    float TargetLenth;

    float angle_kp;
    float angle_ki;
    float angle_kd;
    float angle_Velocity_kp;
    float angle_Velocity_ki;
    float angle_Velocity_kd;
}StateParams;

extern const StateParams stateParams[];*/
extern int32 Jump_Delay;
extern int32 Jump_Flag;
extern float Angel_Get;

extern int16 SINGLE_BRITGH_FLAG;

void pid_init();
void PWM_Limiti(int32 *pwm,int32 limit);
void PWM_Limitf(float *pwm,float limit);
void Con_loop();
void select_Function_Params();



#endif /* CODE_CONTROL_H_ */
